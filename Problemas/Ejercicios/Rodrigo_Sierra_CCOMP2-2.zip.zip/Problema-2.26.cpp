#include <iostream>
using namespace std;

int main () {

    cout<<"Forma larga: "<<endl;
    cout<<"* * * * * * * "<<endl;
    cout<<" * * * * * * * "<<endl;
    cout<<"* * * * * * * "<<endl;
    cout<<" * * * * * * * "<<endl;
    cout<<"* * * * * * * "<<endl;
    cout<<" * * * * * * * "<<endl;
    cout<<"* * * * * * * "<<endl;
    cout<<" * * * * * * * "<<endl;


    cout<<"Forma corta: "<<endl;
    cout<<"* * * * * * * \n * * * * * * \n * * * * * * \n"<<
    " * * * * * * * \n* * * * * * * \n * * * * * * * \n* * * * * * * \n * * * * * * * ";
    return 0;
}